shift.js
copy to web/shifttq/