experimental 2016-11-25


Manual "add peer" to individual torrents via GUI and web client.
Allow any block size with small block size warning.
Minimizes "Invalid or Corrupt" torrents.
Fix minor memory leaks.


example:
add peer 192.168.1.77:51413

torrent must be running

magnet or .torrent file

https://sourceforge.net/p/transmissiondaemon/discussion/general/thread/2c267046/#59ab

__________________________________________________
__________________________________________________

1.) sources/binaries for your platform
http://www.sb-innovation.de/f45/transmission-2-77-2-8x-leecher-mod-windows-linux-31407/#post318795

2.) update-ALL-platforms-111816.zip
http://www.sb-innovation.de/attachments/f45/17235d1480352466-transmission-2-77-2-8x-leecher-mod-windows-linux-update-all-platforms-111816.zip

3.) experimental-2016-11-25.zip
http://www.sb-innovation.de/attachments/f45/17236d1480353133-transmission-2-77-2-8x-leecher-mod-windows-linux-experimental-2016-11-25.zip

copy shift.js to web/shifttq/

